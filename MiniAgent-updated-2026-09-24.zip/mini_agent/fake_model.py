"""Starter-compatible import location for the deterministic fake model."""

from .models import FakeModel

__all__ = ["FakeModel"]
